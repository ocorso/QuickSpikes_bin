###
## Version    : ASH 0.3.0 | USPS 2.0 
## Created by : Greg Gullett & Instinct.co.nz
## Website    : http://wwww.ecsquest.net & http://www.instinct.co.nz
## Please contact me if you have any problems
###

Installation:
 1. Copy plugin folder to /wp-content/plugins/ of your wordpress installation.
 2. Activate WP e-Commerce Plugin Advanced Shipping under your Plugins admin panel

Setting up USPS 2.0
 Existing Users:
 1. Uncheck the old USPS module under Store->Settings->Shipping 
 2. Click >edit< for the old USPS module and copy your USPS ID, Password is not necessary

 New Users:
 1. Go to USPS 2.0 and click >Edit< , click on the link to the USPS API Registration page
 2. Register for your USPS API Access

 Both:
 3. Check the new USPS 2.0 module under Store->Settings->shipping
 4. Enter your USPS ID into the first box provided.
 5. Set the rest of the settings to meet your business needs.


Changelog :
Administration options and requirements have changed!
For USPS you must now have dimensions set on all products if you are going to use international shipping.
The new API Requires this and with implementation of ASH (Advanced Shipping) this is now possible.
Also, you can now take advantage of this system for US Domestic rating by choice. 

Another change is in how the user information is stored. Please back up (write down/ copy paste) your
USPS User ID as it will not be picked up by USPS 2.0 from where 1.0 stores it.


Features List:
 - USPS Version 2.0
  -- Uses the new RateV4 API for US Domestic shipping rates
  -- Uses the new IntlRateV2 API for International shipping rates
  -- New Advanced shipping in use for Internation shipping and optional for US Domestic rating
    --- Each item in the cart is rated as its own package. This provides 
        the most accurate rate possible because it uses the dimensions as set
        on your product (Height, Width, Lenght and Weight) instead of using the 
        total weight only. You will get a more accurate rate every time.
  -- 
  -- USPS Password is no longer needed and has been removed from the interface
  -- Added link to the USPS webtools registration page
  -- Added checkbox to select using Advanced Shipping for US Domestic rating
  -- Added ability to control selected services via the admin panel
  -- Added international package type selection
  -- Added first class mail type selection

 - ASH Version 0.3.0
  -- Provides a centralized shipment object based off of the cart for easier 
     integration of shipping API into WPEC. your one stop shop for package dimensions, weights 
     and destination!
  -- Provides access to more meta data about products including the use of some new meta data
    --- New Meta Data available for use:
        * "ship_hazard" = TRUE or FALSE // Denotes if this item is hazardous material
        * "ship_insurance" = TRUE or FALSE // Denotes if you want to carry insurance on an item
        * "ship_insured_amount" =  x.xx // How much you want to insure the package for
  -- The above Meta Data are not in use at this time via USPS but will be used in coming versions of ASH
  -- ASH provides a centralized and uniform interface for cacheing rate table results and 
     checking that the cache is still valid versus the current shipment / destination.
     This way we eventually will have uniform cache use between all shipping modules and better page load performance!