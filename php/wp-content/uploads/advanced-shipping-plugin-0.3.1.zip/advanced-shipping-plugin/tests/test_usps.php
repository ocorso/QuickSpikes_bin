<?php
include "ash_test_class.php";

class test_usps extends ASHTest{
    
    function get_domestic_quote(){
        $shipment = $this->build_test_shipment(2);
        $dest = array(
            "state"=>"North Carolina",
            "country"=>"USA",
            "zipcode"=>"28360"
        );
        
        $shipment->set_destination("usps",$dest);
        
        $test_data = array(
            "user_id" => "",  // Put your API ID here
            "fcl_type" => "LETTER",
            "mail_type" => "Package",
            "base_zipcode"=> "32608",
            "dest_zipcode"=> $shipment->destination["zipcode"],
            "services" => array("ONLINE"),
            "weight" => $shipment->total_weight,
            "dest_country" => $shipment->destination["country"],
            "value"=>$shipment->shipment_value,
            "adv_rate"=>TRUE
        );
        $usps = new ash_usps();
        $result = $usps->test($test_data, $shipment);
        print "<hr />USPS Domestic Quote<hr />\n<pre>";
        print_r($result);
        print "</pre>\n<hr />SHIPMENT VALUES<hr>\n";
        print_r($shipment);
    }
    
    function get_intl_quote(){
        $shipment = $this->build_test_shipment(1);
        $dest = array(
            "state"=>"",
            "country"=>"Turkmenistan",
            "zipcode"=>"00603"
        );
        
        $shipment->set_destination("usps",$dest);
        
        $test_data = array(
            "user_id" => "",  // Put your API ID here
            "fcl_type" => "LETTER",
            "mail_type" => "Package",
            "base_zipcode"=> "18701",
            "dest_zipcode"=> $shipment->destination["zipcode"],
            "services" => array("Package"),
            "weight" => $shipment->total_weight,
            "dest_country" => $shipment->destination["country"],
            "value"=>$shipment->shipment_value
        );
        $usps = new ash_usps($shipment);
        
        $result = $usps->test($test_data, $shipment);

        print "<hr />USPS International Quote<hr />\n<pre>";
        print_r($result);
        print "</pre>\n<hr />SHIPMENT VALUES<hr>\n";
        print_r($shipment);
    }
}
print "UPS Test Initiating<br />";
$test = new test_usps();
$test->get_domestic_quote();
$test->get_intl_quote();