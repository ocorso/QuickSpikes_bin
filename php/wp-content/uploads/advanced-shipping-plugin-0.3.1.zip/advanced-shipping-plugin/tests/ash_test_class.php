<?php
session_start();
include "../wpec_ash.php";

/**
 * Builds a mock-shipment for testing
 * @param number of items $item_count will add ($item_count * 2) to the weight
 * @return ASHShipment
 */
class ASHTest{
    function build_test_shipment($item_count){
        $shipment = new ASHShipment();
        for($i = 0; $i < $item_count; $i++){
            $package = new ASHPackage();
            $package->weight = (10.0 + ($i * 2));
            $dim_array = array();
            $dim_array["height"] =  5;
            $dim_array["width"] = 5;
            $dim_array["length"] = 5;
            $package->set_dimensions($dim_array);
            $package->contents = "Test Product ".$i;
            $package->value = 1.5;
            $shipment->add_package($package);
        }
        return $shipment;
    }
}