<?php
/*
Plugin Name: WP e-Commerce Plugin Advanced Shipping
Plugin URI: http://www.ecsquest.net
Description: This plugin replaces the basic shipping provided in WPEC with more advanced versions that take into account dimensions for shipping.
Version: 0.3.1
Author: Greg Gullett
Author URI: http://www.ecsquest.net
Tested up to: 3.1
*/
if (!is_array($_SESSION)){
    session_start();
}

define('ASH_FILE_PATH', dirname(__FILE__));
define('ASH_INCLUDES', ASH_FILE_PATH."/includes/");
include_once 'includes/shipping.helper.php';

global $wpec_ash;
$wpec_ash = new ASH();
global $wpec_ash_xml;
$wpec_ash_xml = new ASHXML();
global $wpec_ash_tools;
$wpec_ash_tools = new ASHTools;

//include_once 'modules/fedex.php'; // Integration with latest ASH is not complete
//include_once 'modules/ups.php';   // Integration with latest ASH is not complete
include_once 'modules/usps.php';

function add_modules() {
    global $wpsc_shipping_modules;
    //$fedex = new ash_fedex();
    //$wpsc_shipping_modules[$fedex->getInternalName()] = $fedex;
    //$ups = new ash_ups();
    //$wpsc_shipping_modules[$ups->getInternalName()] = $ups;
    $usps = new ash_usps();
    $wpsc_shipping_modules[$usps->getInternalName()] = $usps;
    
    return $wpsc_shipping_modules;
}
add_modules();
